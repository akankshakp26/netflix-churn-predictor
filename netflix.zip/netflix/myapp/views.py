from django.shortcuts import render
import pandas as pd
import numpy as np
import pickle

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

from xgboost import XGBClassifier
global X_train, y_train, scaler, encoders, X, model,X_test,y_pred,y_test

def index(request):
    return render(request,'myapp/index.html')

def dataupload(request):
    global X_train, y_train, scaler, encoders, X, model, X_test, y_pred, y_test

    df = pd.read_csv("netflix_customer_churn.csv")

    df.dropna(inplace=True)

    columns_to_drop = ['customer_id', 'Customer_ID', 'id', 'ID']
    for col in columns_to_drop:
        if col in df.columns:
            df.drop(col, axis=1, inplace=True)

    possible_targets = ['churned', 'Churn', 'churn', 'Exited', 'target', 'label']
    TARGET_COLUMN = None
    for col in possible_targets:
        if col in df.columns:
            TARGET_COLUMN = col
            break
    if TARGET_COLUMN is None:
        TARGET_COLUMN = df.columns[-1]

    encoders = {}
    categorical_cols = df.select_dtypes(include='object').columns
    for col in categorical_cols:
        encoder = LabelEncoder()
        df[col] = encoder.fit_transform(df[col].astype(str))
        encoders[col] = encoder

    X = df.drop(TARGET_COLUMN, axis=1)
    y = df[TARGET_COLUMN]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    content = {
        'total_rows':       df.shape[0],
        'total_cols':       df.shape[1],
        'target_column':    TARGET_COLUMN,
        'num_features':     X.shape[1],
        'train_size':       X_train.shape[0],
        'test_size':        X_test.shape[0],
        'missing_values':   0,
        'categorical_cols': list(categorical_cols),
        'num_cat':          len(categorical_cols),
        'columns':          df.columns.tolist(),
    }

    return render(request, 'myapp/dataupload.html', content)



def modeltraining(request):
    global X_train, y_train, scaler, encoders, X, model, X_test, y_pred, y_test

    model = XGBClassifier(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=8,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42
    )

    model.fit(X_train, y_train)

    pickle.dump(model,   open('churn_model.pkl', 'wb'))
    pickle.dump(scaler,  open('churn_scaler.pkl', 'wb'))
    pickle.dump(encoders, open('churn_encoders.pkl', 'wb'))
    pickle.dump(X.columns.tolist(), open('feature_columns.pkl', 'wb'))

    content = {
        'n_estimators': 500,
        'learning_rate': 0.05,
        'max_depth': 8,
        'subsample': 0.8,
        'colsample_bytree': 0.8,
        'train_size': X_train.shape[0],
        'test_size': X_test.shape[0],
        'n_features': X_train.shape[1],
    }

    return render(request, 'myapp/modeltraining.html', content)


def prediction(request):
    global X_train, y_train, scaler, encoders, X, model, X_test, y_pred, y_test

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    content = {
        'accuracy': round(accuracy * 100, 2),
    }

    return render(request, 'myapp/prediction.html', content)
def evaluation(request):
    global X_train, y_train, scaler, encoders, X, model, X_test, y_pred, y_test

    # Run prediction here directly (don't rely on prediction view being called first)
    y_pred = model.predict(X_test)

    accuracy  = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall    = recall_score(y_test, y_pred)
    f1        = f1_score(y_test, y_pred)

    cm     = confusion_matrix(y_test, y_pred).tolist()
    report = classification_report(y_test, y_pred)

    content = {
        'data0': round(accuracy  * 100, 2),
        'data1': report,
        'data2': cm,
        'data3': round(precision * 100, 2),
        'data4': round(recall    * 100, 2),
        'data5': round(f1       * 100, 2),
    }

    return render(request, 'myapp/evaluation.html', content)